"use client";

import React, { useState } from "react";
import { joinClass } from "../../../services/communicationManager";
import { useRouter } from 'next/navigation';
import { useAuthStore } from '../../../stores/authStore';
import Title from "app/components/atoms/Title";
import Input from "app/components/atoms/Input";
import Button from "app/components/atoms/Button";
import PanelBox from "app/components/atoms/PanelBox";
import Panel from "app/components/atoms/Panel";

const JoinClassForm = () => {
  const router = useRouter();
  const [classCode, setClassCode] = useState("");
  const userInfo = useAuthStore((state) => state.user_info);

  const handleJoin = async () => {
    if (classCode) {
      try {
        const response = await joinClass(classCode);
        if (response.class_info) {
          router.push(userInfo.role == 1 ? '/PfPage' : '/StPage');
        } else {
          alert("Failed to join class. Please check your details.");
        }
      } catch (error) {
        console.error("Error joining class:", error);
        alert("An error occurred while joining the class.");
      }
    } else {
      alert("Please enter the class code.");
    }
  };

  return (
    <Panel>
      <PanelBox className=" ml-200">
      <div>
      <Title>Uneix-te a una classe existent</Title>
      </div>
      <Input
      placeholder="Class Code"
      value={classCode}
      onChange={(e) => setClassCode(e.target.value)}
      />
      <Button className="bg-white" onClick={handleJoin}>Join Class</Button>
      </PanelBox>
    </Panel>
  );
};

export default JoinClassForm;
