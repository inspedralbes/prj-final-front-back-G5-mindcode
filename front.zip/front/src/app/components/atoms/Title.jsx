const Title = ({ children }) => (
    <h5 className="text-1xl font-bold mb-6 text-center">{children}</h5>
  );
  export default Title;
  