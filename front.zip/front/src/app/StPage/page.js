"use client";

  import StudentDashboardPage from "../components/templates/StudentDashboardPage";

export default function Page() {
  return <StudentDashboardPage />;
}
